# Module 05 — Events

User-facing events implementation: listing approved upcoming events, event details, registration/cancellation, and event creation with admin approval.

Database schema is unchanged.

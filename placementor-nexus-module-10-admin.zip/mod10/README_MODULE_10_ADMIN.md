# Module 10 — Admin & Moderation

This module implements the existing Placementor Nexus admin/moderation layer against the Prisma schema.

Included:
- Admin RBAC via `lib/admin-permissions.ts`
- `/admin` dashboard and analytics
- User listing/search/role/suspension management
- Reports listing and report resolution/rejection
- Jobs/events moderation
- Community moderation
- Company/recruiter management
- Admin notification broadcasts
- Audit log
- System health

The module uses the existing `Profile`, `Report`, `AuditLog`, `AdminNotification`, and `UserSuspension` models. No Prisma schema change is required.

## Install

From the project root:

```bash
unzip -o placementor-nexus-module-10-admin.zip -d /tmp/module10
cp -r /tmp/module10/mod10/app-admin/* app/admin/
cp -r /tmp/module10/mod10/components-admin/* components/admin/
cp -r /tmp/module10/mod10/services-admin/* services/admin/
cp /tmp/module10/mod10/admin-permissions.ts lib/admin-permissions.ts
cp /tmp/module10/mod10/use-admin.ts hooks/use-admin.ts
```

Then run:

```bash
npx tsc --noEmit
npm run build
```

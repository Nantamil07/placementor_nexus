import { ReferralActions } from "./ReferralActions";
import type { ReferralView } from "@/services/referral/get-referrals";

export function ReferralCard({ referral, mode }: { referral: ReferralView; mode: "sent" | "received" }) {
  const person = mode === "sent" ? referral.referrer : referral.requester;
  const date = new Date(referral.createdAt).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" });
  return <article className="rounded-xl border bg-card p-5 shadow-sm">
    <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
      <div><h3 className="font-semibold">{referral.jobTitle}</h3><p className="mt-1 text-sm text-muted-foreground">{referral.company?.name ?? "Company not specified"}</p><p className="mt-2 text-xs text-muted-foreground">{mode === "sent" ? "Requested from" : "Requested by"} <span className="font-medium text-foreground">{person.fullName}</span> · {date}</p></div>
      <span className="w-fit rounded-full bg-muted px-2.5 py-1 text-xs font-semibold">{referral.status}</span>
    </div>
    {referral.notes && <p className="mt-4 rounded-lg bg-muted/40 p-3 text-sm leading-relaxed">{referral.notes}</p>}
    <div className="mt-4 flex flex-wrap gap-3 text-xs"><>{referral.jobUrl && <a href={referral.jobUrl} target="_blank" rel="noreferrer" className="font-medium text-primary hover:underline">Job posting</a>}</>{referral.resumeUrl && mode === "received" && <a href={referral.resumeUrl} target="_blank" rel="noreferrer" className="font-medium text-primary hover:underline">Resume</a>}</></div>
    {mode === "received" && referral.status === "PENDING" && <div className="mt-4"><ReferralActions referralId={referral.id} /></div>}
  </article>;
}

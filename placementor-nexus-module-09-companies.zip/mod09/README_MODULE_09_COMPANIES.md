# Module 09 — Companies

## Features
- PostgreSQL-backed company directory
- Company search by name, location, or description
- Verified-company indicator
- Persistent company follow/unfollow using CompanyFollower
- Company detail pages
- Follower count
- Company website link
- Approved jobs displayed on company pages
- Clerk authentication for follow actions

## No schema changes
Uses the existing Company, CompanyFollower, and Job models.

## Install
```bash
cp -r mod09/services/company/* services/company/
cp -r mod09/components/company/* components/company/
cp -r "mod09/app/(main)/companies/"* "app/(main)/companies/"
```

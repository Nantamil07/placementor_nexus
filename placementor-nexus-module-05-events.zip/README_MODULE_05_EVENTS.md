# Module 05 — Events

This module contains the existing Events source from Placementor Nexus.

Copy these files into the project, then validate with:

    npx prisma generate
    npx tsc --noEmit
    npm run build

No Prisma schema changes are included in this module.
